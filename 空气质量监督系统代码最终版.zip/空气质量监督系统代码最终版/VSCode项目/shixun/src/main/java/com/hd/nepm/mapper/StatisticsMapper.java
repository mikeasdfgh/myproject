package com.hd.nepm.mapper;

import com.hd.nepm.po.Statistics;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface StatisticsMapper {
    @Select("SELECT s.*, p.province_name provinceName, c.city_name cityName, f.tel_id telId" +
            " FROM statistics s" +
            " LEFT JOIN grid_province p ON s.province_id = p.province_id" +
            " LEFT JOIN grid_city c ON s.city_id = c.city_id" +
            " LEFT JOIN aqi_feedback f ON s.fd_id = f.af_id")
    List<Statistics> selectAllStatistics();

    @Select("SELECT s.*, p.province_name provinceName, c.city_name cityName, f.tel_id telId" +
            " FROM statistics s" +
            " LEFT JOIN grid_province p ON s.province_id = p.province_id" +
            " LEFT JOIN grid_city c ON s.city_id = c.city_id" +
            " LEFT JOIN aqi_feedback f ON s.fd_id = f.af_id" +
            " WHERE s.fd_id = #{fdId}")
    Statistics selectByFdId(Integer fdId);

    @Insert("INSERT INTO statistics (province_id, city_id, address, so2_value, so2_level, " +
            "co_value, co_level, spm_value, spm_level, aqi_id, confirm_date, confirm_time, " +
            "gm_id, fd_id, information, remarks) " +
            "VALUES (#{provinceId}, #{cityId}, #{address}, #{so2Value}, #{so2Level}, " +
            "#{coValue}, #{coLevel}, #{spmValue}, #{spmLevel}, #{aqiId}, #{confirmDate}, #{confirmTime}, " +
            "#{gmId}, #{fdId}, #{information}, #{remarks})")
    int insert(Statistics statistics);
}
