package com.hd.nepm.service.impl;

import com.hd.nepm.mapper.AqiFeedBackMapper;
import com.hd.nepm.mapper.AqiMapper;
import com.hd.nepm.mapper.StatisticsMapper;
import com.hd.nepm.po.AqiFeedBack;
import com.hd.nepm.po.Statistics;
import com.hd.nepm.service.StatisticsService;
import com.hd.nepm.vo.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class StatisticsServiceI implements StatisticsService {
    @Autowired
    private StatisticsMapper statisticsMapper;

    @Autowired
    private AqiFeedBackMapper aqiFeedBackMapper;

    @Autowired
    private AqiMapper aqiMapper;

    @Override
    public List<Statistics> selectAll() {
        return statisticsMapper.selectAllStatistics();
    }

    @Override
    @Transactional
    public ResponseData<Statistics> confirm(AqiFeedBack aqiFeedBack) {
        AqiFeedBack feedback = aqiFeedBackMapper.selectById(aqiFeedBack.getAfId());
        if (feedback == null) {
            return ResponseData.error(500, "未找到对应的反馈记录");
        }

        if (feedback.getState() == null || feedback.getState() != 1) {
            return ResponseData.error(500, "该反馈单尚未指派，无法确认");
        }

        Integer so2Value = aqiFeedBack.getSo2Value() != null ? aqiFeedBack.getSo2Value() : 0;
        Integer coValue = aqiFeedBack.getCoValue() != null ? aqiFeedBack.getCoValue() : 0;
        Integer spmValue = aqiFeedBack.getSpmValue() != null ? aqiFeedBack.getSpmValue() : 0;

        Integer so2Level = aqiMapper.getSo2Level(so2Value);
        Integer coLevel = aqiMapper.getCoLevel(coValue);
        Integer spmLevel = aqiMapper.getSpmLevel(spmValue);

        if (so2Level == null) so2Level = 1;
        if (coLevel == null) coLevel = 1;
        if (spmLevel == null) spmLevel = 1;

        Statistics statistics = new Statistics();
        statistics.setProvinceId(feedback.getProvinceId());
        statistics.setCityId(feedback.getCityId());
        statistics.setAddress(feedback.getAddress());
        statistics.setInformation(feedback.getInformation());
        statistics.setFdId(aqiFeedBack.getAfId());
        statistics.setGmId(feedback.getGmId() != null ? feedback.getGmId() : 0);
        statistics.setConfirmDate(java.time.LocalDate.now().toString());
        statistics.setConfirmTime(java.time.LocalTime.now().toString().substring(0, 8));

        statistics.setSo2Value(so2Value);
        statistics.setSo2Level(so2Level);
        statistics.setCoValue(coValue);
        statistics.setCoLevel(coLevel);
        statistics.setSpmValue(spmValue);
        statistics.setSpmLevel(spmLevel);

        // 综合 AQI 等级取各污染物等级的最大值
        int aqiId = Math.max(Math.max(so2Level, coLevel), spmLevel);
        statistics.setAqiId(aqiId);

        statistics.setRemarks(aqiFeedBack.getRemarks());

        int rows = statisticsMapper.insert(statistics);
        if (rows > 0) {
            AqiFeedBack updateFeedback = new AqiFeedBack();
            updateFeedback.setAfId(aqiFeedBack.getAfId());
            updateFeedback.setState(2);
            aqiFeedBackMapper.updateStatus(updateFeedback);
            return ResponseData.success(statistics);
        } else {
            return ResponseData.error(500, "核验记录添加失败");
        }
    }

    @Override
    public ResponseData<Statistics> getByFdId(Integer fdId) {
        Statistics statistics = statisticsMapper.selectByFdId(fdId);
        if (statistics == null) {
            return ResponseData.error(500, "未找到该反馈的检测记录");
        }
        return ResponseData.success(statistics);
    }
}
