package com.hd.nepm.service.impl;

import com.hd.nepm.mapper.AqiMapper;
import com.hd.nepm.po.Aqi;
import com.hd.nepm.service.AqiService;
import com.hd.nepm.vo.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AqiServiceImpl implements AqiService {
    @Autowired
    private AqiMapper aqiMapper;

    @Override
    public ResponseData<List<Aqi>> selectAll() {
        List<Aqi> list = aqiMapper.selectAll();
        if (list != null && !list.isEmpty()) {
            return ResponseData.success(list);
        } else {
            return ResponseData.error(500, "查询失败");
        }
    }

    @Override
    public ResponseData<Aqi> selectById(Integer aqiId) {
        Aqi aqi = aqiMapper.selectById(aqiId);
        if (aqi != null) {
            return ResponseData.success(aqi);
        } else {
            return ResponseData.error(500, "未找到对应记录");
        }
    }

    @Override
    public ResponseData<Aqi> insert(Aqi aqi) {
        int rows = aqiMapper.insert(aqi);
        if (rows > 0) {
            return ResponseData.success(aqi);
        } else {
            return ResponseData.error(500, "添加失败");
        }
    }

    @Override
    public ResponseData<Aqi> update(Aqi aqi) {
        int rows = aqiMapper.update(aqi);
        if (rows > 0) {
            return ResponseData.success(aqi);
        } else {
            return ResponseData.error(500, "更新失败");
        }
    }

    @Override
    public ResponseData<String> deleteById(Integer aqiId) {
        int rows = aqiMapper.deleteById(aqiId);
        if (rows > 0) {
            return ResponseData.success("删除成功");
        } else {
            return ResponseData.error(500, "删除失败");
        }
    }
}
