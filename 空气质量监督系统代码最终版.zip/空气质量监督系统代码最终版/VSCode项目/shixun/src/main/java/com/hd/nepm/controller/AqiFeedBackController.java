package com.hd.nepm.controller;

import com.hd.nepm.po.AqiFeedBack;
import com.hd.nepm.service.impl.AqiFeedBackServiceI;
import com.hd.nepm.vo.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/aqiFeedBack")
@CrossOrigin
public class AqiFeedBackController {
    @Autowired
    private AqiFeedBackServiceI aqiFeedBackServicei;
    
    @PostMapping("/insert")
    public ResponseData insert(@RequestBody AqiFeedBack aqiFeedBack) {
        System.out.println("接收到的反馈数据: " + aqiFeedBack);
        return ResponseData.success(aqiFeedBackServicei.insert(aqiFeedBack));
    }
    
    @GetMapping("/findAll")
    public ResponseData findAll() {
        return ResponseData.success(aqiFeedBackServicei.findAll());
    }
    
    @GetMapping("/findAllForAdmin")
    public ResponseData findAllForAdmin() {
        return ResponseData.success(aqiFeedBackServicei.findAllForAdmin());
    }

    @GetMapping("/findByGmId")
    public ResponseData findByGmId(@RequestParam("gmId") Integer gmId) {
        return ResponseData.success(aqiFeedBackServicei.findByGmId(gmId));
    }

        @PutMapping("/updateAssignment")
        public ResponseData updateAssignment(@RequestBody AqiFeedBack aqiFeedBack) {
            return ResponseData.success(aqiFeedBackServicei.updateAssignment(aqiFeedBack));
    }
}
