package com.hd.nepm.service.impl;

import com.hd.nepm.mapper.AdminsMapper;
import com.hd.nepm.po.Admins;
import com.hd.nepm.service.AdminsService;
import com.hd.nepm.vo.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Package: com.hd.nepm.service.impl
 * Description：
 *
 * @Author msy
 * @Create 2026/6/24 9:50
 * @Version 1.0
 */
@Service
public class AdminsServiceI implements AdminsService {
    @Autowired
    private AdminsMapper adminsMapper;
    @Override
    public ResponseData<Admins> insertAdmins(Admins admins) {
        int rows = adminsMapper.insertAdmins(admins);
        if (rows > 0) {
            return ResponseData.success(admins);
        } else {
            return ResponseData.error(2001, "插入失败");
        }
    }
    @Override
    public ResponseData<Admins> selectAdminsByCodeAndPassword(Admins admins) {
        Admins admins1 = adminsMapper.selectAdminsByCode(admins.getAdminCode());
        if (admins1 == null)
            return ResponseData.error(400, "用户名不存在");
        else {
            if (!admins1.getPassword().equals(admins.getPassword())) {
                return ResponseData.error(1001, "密码错误");
            } else {
                return ResponseData.success(admins1);
            }
        }
    }
}