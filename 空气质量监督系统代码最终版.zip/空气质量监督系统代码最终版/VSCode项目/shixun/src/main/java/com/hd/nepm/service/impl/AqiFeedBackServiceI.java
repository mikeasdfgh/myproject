package com.hd.nepm.service.impl;

import com.hd.nepm.mapper.AqiFeedBackMapper;
import com.hd.nepm.po.AqiFeedBack;
import com.hd.nepm.service.AqiFeedBackService;
import com.hd.nepm.vo.ResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Package: com.hd.nepm.service.impl
 * Description：
 *
 * @Author msy
 * @Create 2026/6/30 11:55
 * @Version 1.0
 */
@Service
public class AqiFeedBackServiceI implements AqiFeedBackService {
    @Autowired
    private AqiFeedBackMapper aqiFeedBackMapper;
    
    @Override
    public List<AqiFeedBack> findAll() {
        return aqiFeedBackMapper.findAll();
    }
    
    @Override
    public List<AqiFeedBack> findAllForAdmin() {
        return aqiFeedBackMapper.findAllForAdmin();
    }

    @Override
    public List<AqiFeedBack> findByGmId(Integer gmId) {
        return aqiFeedBackMapper.findByGmId(gmId);
    }

    @Override
    public ResponseData<AqiFeedBack> insert(AqiFeedBack aqiFeedBack) {
        if(aqiFeedBack.getEstimatedGrade() == null || aqiFeedBack.getEstimatedGrade() == 0) {
            aqiFeedBack.setEstimatedGrade(1);
        }
        if(aqiFeedBack.getAfDate() == null || aqiFeedBack.getAfDate().isEmpty()) {
            java.time.LocalDate now = java.time.LocalDate.now();
            aqiFeedBack.setAfDate(now.toString());
        }
        if(aqiFeedBack.getAfTime() == null || aqiFeedBack.getAfTime().isEmpty()) {
            java.time.LocalTime now = java.time.LocalTime.now();
            aqiFeedBack.setAfTime(now.toString().substring(0, 5));
        }
        if(aqiFeedBack.getGmId() == null) {
            aqiFeedBack.setGmId(0);
        }
        if(aqiFeedBack.getState() == null) {
            aqiFeedBack.setState(0);
        }
        if(aqiFeedBackMapper.insert(aqiFeedBack) > 0) {
            return ResponseData.success(aqiFeedBack);
        } else
            return ResponseData.error(500, "添加失败");
    }
    
    @Override
    public ResponseData<AqiFeedBack> updateAssignment(AqiFeedBack aqiFeedBack) {
        if(aqiFeedBackMapper.updateAssignment(aqiFeedBack) > 0)
            return ResponseData.success(aqiFeedBack);
        else
            return ResponseData.error(500, "分配失败");
    }
}
