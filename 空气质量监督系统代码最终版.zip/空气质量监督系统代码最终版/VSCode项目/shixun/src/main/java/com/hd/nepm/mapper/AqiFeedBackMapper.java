package com.hd.nepm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hd.nepm.po.AqiFeedBack;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * Package: com.hd.nepm.mapper
 * Description：
 *
 * @Author msy
 * @Create 2026/6/30 11:46
 * @Version 1.0
 */
@Mapper
public interface AqiFeedBackMapper extends BaseMapper<AqiFeedBack> {
    @Select("SELECT af.af_id afId, af.tel_id telId, af.province_id provinceId, af.city_id cityId, " +
            "af.address, af.information, af.estimated_grade estimatedGrade, af.state, " +
            "af.af_date afDate, af.af_time afTime, " +
            "p.province_name provinceName, c.city_name cityName " +
            "FROM aqi_feedback af " +
            "LEFT JOIN grid_province p ON af.province_id = p.province_id " +
            "LEFT JOIN grid_city c ON af.city_id = c.city_id")
    List<AqiFeedBack> findAll();
    
    @Select("SELECT af.*, p.province_name provinceName, c.city_name cityName " +
            "FROM aqi_feedback af " +
            "LEFT JOIN grid_province p ON af.province_id = p.province_id " +
            "LEFT JOIN grid_city c ON af.city_id = c.city_id")
    List<AqiFeedBack> findAllForAdmin();
    
    @Insert("INSERT INTO aqi_feedback (tel_id, province_id, city_id, address, information, estimated_grade, af_date, af_time, gm_id, state) " +
            "VALUES (#{telId}, #{provinceId}, #{cityId}, #{address}, #{information}, #{estimatedGrade}, #{afDate}, #{afTime}, #{gmId}, #{state})")
    int insert(AqiFeedBack aqiFeedBack);

    @Update("UPDATE aqi_feedback SET gm_id = #{gmId}, assign_date = #{assignDate}, " +
            "assign_time = #{assignTime}, state = #{state}, remarks = #{remarks} " +
            "WHERE tel_id = #{telId}")
    int updateAssignment(AqiFeedBack aqiFeedBack);

    @Update("UPDATE aqi_feedback SET state = #{state} WHERE af_id = #{afId}")
    int updateStatus(AqiFeedBack aqiFeedBack);

    @Select("SELECT af.*, p.province_name provinceName, c.city_name cityName " +
            "FROM aqi_feedback af " +
            "LEFT JOIN grid_province p ON af.province_id = p.province_id " +
            "LEFT JOIN grid_city c ON af.city_id = c.city_id " +
            "WHERE af.af_id = #{afId}")
    AqiFeedBack selectById(Integer afId);

    @Select("SELECT af.*, p.province_name provinceName, c.city_name cityName " +
            "FROM aqi_feedback af " +
            "LEFT JOIN grid_province p ON af.province_id = p.province_id " +
            "LEFT JOIN grid_city c ON af.city_id = c.city_id " +
            "WHERE af.gm_id = #{gmId}")
    List<AqiFeedBack> findByGmId(Integer gmId);

    @Select("SELECT city_id FROM grid_member WHERE gm_id = #{gmId}")
    Integer selectCityIdByGmId(Integer gmId);

    @Select("SELECT af.city_id FROM aqi_feedback af WHERE af.af_id = #{afId}")
    Integer selectCityIdByAfId(Integer afId);

}
