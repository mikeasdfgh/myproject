---
name: leaflet-map-picker
description: 在 Vue3 项目中创建基于 Leaflet 的街道级地图位置选择器组件，默认使用高德瓦片（国内可访问），支持 WGS84/GCJ02 坐标转换、浏览器定位、地图点击选点、地点搜索、逆地理编码解析省市区街道并自动回填表单。点击地图不强制缩放，避免地图乱跳。
agent_created: true
---

# Leaflet 街道级地图定位选择器

## 概述

在 Vue3 项目中集成 Leaflet，提供一个可复用的街道级地图位置选择器组件。组件特性：

- 默认使用**高德地图瓦片**，国内访问速度快；支持切换到 OpenStreetMap
- 内置 **WGS84 ↔ GCJ02（火星坐标）** 转换，确保浏览器定位、地图显示、反地理编码坐标一致
- 浏览器 `navigator.geolocation` 一键定位当前位置
- 点击地图或拖拽标记选点；**点击地图只移动标记，不强制缩放，避免地图乱跳**
- 地点关键词搜索（Nominatim）
- 逆地理编码解析省、市、区、街道并回填地址（**BigDataCloud 优先；解析失败或街道缺失时回退 Nominatim**）
- 街道输入框与详细地址联动：编辑街道后自动同步到详细地址末尾
- 对话框与 Leaflet 控件使用**中文简体**字体（PingFang SC / Microsoft YaHei）
- 自动匹配并回填表单中的省份/城市下拉框
- 取消正在进行的上一次反地理编码请求，避免结果覆盖或 AbortError 噪音
- 反地理编码结果通过 `opencc-js` 转换为**简体中文**，避免 Nominatim 返回繁体中文导致表单城市匹配失败

## 使用场景

当用户需求中出现以下关键词或场景时触发本 skill：

- "地图定位"、"地图选点"、"实时定位"、"定位到当前位置"
- 表单中需要通过地图选择详细地址
- 需要获取用户当前位置并解析省市区街道
- 需要比 ECharts 中国省级地图更详细的街道地图
- 国内网络环境下 OpenStreetMap 加载失败
- 地图点击/定位时"乱跳"、"闪动"、影响操作

## 实现步骤

### 1. 安装依赖

```bash
npm install leaflet opencc-js
```

### 2. 创建地图选择器组件

在 `src/components/MapLocationPicker.vue` 中实现：

- 使用 `import L from 'leaflet'` 和 `import 'leaflet/dist/leaflet.css'`
- 使用 `import OpenCC from 'opencc-js'` 并创建繁体转简体转换器：`const toSimplified = OpenCC.Converter({ from: 'tw', to: 'cn' })`，对反地理编码解析出的 province/city/district/street/address 统一转简体中文
- 在 `el-dialog` 的 `@opened` 事件中初始化地图（确保 DOM 已渲染）
- 默认加载**高德瓦片**：`https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}`
- 提供瓦片源切换按钮（高德 / OSM），使用 `el-radio-button` 的 `value` 属性避免 Element Plus 弃用警告
- 内部统一以 **WGS84** 存储坐标；显示在高德瓦片（GCJ02）上时进行坐标转换
- 点击地图得到 GCJ02，通过 `gcj02ToWgs84()` 转为 WGS84 后存储；调用 `updateMarker(..., false)`，**不强制 setView/zoom**，保持当前缩放，只移动标记
- 定位当前位置 / 搜索地点时调用 `updateMarker(..., true)`，将地图移动到目标位置并放大到街道级（zoom 16）
- 使用自定义 `L.divIcon` 标记，避免 Leaflet 默认图标在打包后路径错误
- 标记支持 `draggable: true`，拖拽结束后重新反地理编码，但不重新居中地图
- 返回数据结构：`{ lat, lng, address, province, city, district, street }`
- 街道解析增强：
  - `parseBigDataCloudAddress`：从 `localityInfo.administrative` 的 `adminLevel 8~10` 中提取街道名；若 `locality` 本身比城市更细也作为街道候选
  - `parseNominatimAddress`：组合 `road/street/pedestrian/path/house_number/neighbourhood/quarter` 等多个字段，提升街道解析成功率
  - 反地理编码时，若 BigDataCloud 返回地址但街道为空，仍 fallback 到 Nominatim 获取街道信息
- 街道输入联动：监听 `addressForm.street`，自动追加/替换详细地址末尾的街道名，避免用户手动输入后丢失
- 支持 `region` prop：`{ province: '辽宁省', city: '大连市' }`。打开弹窗时，若用户已填写省份/城市，地图会自动搜索并定位到该城市区域
- 对话框与 Leaflet 控件字体统一为中文简体：`font-family: "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", "Helvetica Neue", Arial, sans-serif`
- **响应式对话框尺寸**：`width="85vw"` + `max-width: 900px`，`max-height: 90vh`，顶部留出 `5vh` 边距
- **布局稳定**：顶部工具栏（搜索+地图切换）、地图下方“定位到当前位置”操作栏、地址卡片与底部确定/取消按钮始终固定可见；中间内容区域（地图+地址卡片）可滚动，避免地图过大撑满屏幕导致按钮被挤出
- 地图高度固定 `280px`（最小 `200px`），不再使用 `40vh` 等相对高度，防止小屏幕上地图抢占全部空间
- 对话框打开 260ms 后调用 `mapInstance.invalidateSize()`，确保 Leaflet 在对话框动画结束后正确计算容器尺寸

组件 props：`modelValue` 控制显隐，`initialCoord` 初始坐标，`region` 默认省市区域；事件：`select`。

参考实现见本 skill `assets/MapLocationPicker.vue`。

### 3. WGS84 ↔ GCJ02 坐标转换（内联实现）

由于高德瓦片使用 GCJ02 坐标系，而浏览器定位与 Nominatim 使用 WGS84，需要在组件内实现双向转换：

```js
const wgs84ToGcj02 = (lng, lat) => { /* ... */ } // 返回 [lat, lng]
const gcj02ToWgs84 = (lng, lat) => { /* ... */ } // 返回 [lat, lng]
```

### 4. 反地理编码：取消旧请求 + 双源回退

核心逻辑：

```js
let reverseGeocodeController = null
let reverseGeocodeTimer = null

const cancelPendingReverseGeocode = () => {
  if (reverseGeocodeTimer) {
    clearTimeout(reverseGeocodeTimer)
    reverseGeocodeTimer = null
  }
  if (reverseGeocodeController) {
    try { reverseGeocodeController.abort() } catch (e) { /* ignore */ }
    reverseGeocodeController = null
  }
}

const reverseGeocode = async (lat, lng) => {
  cancelPendingReverseGeocode()
  // 先尝试 BigDataCloud（国内更稳定），超时/失败再尝试 Nominatim
  // 对 AbortError 不打印警告，避免控制台噪音
}
```

### 5. 在表单中集成

在表单中集成，并将已选省份/城市作为默认区域传给地图：

```vue
<script setup>
import { ref, reactive, nextTick, computed } from 'vue'
import { MapLocation } from '@element-plus/icons-vue'
import MapLocationPicker from '@/components/MapLocationPicker.vue'

const mapPickerVisible = ref(false)
const provinceList = ref([])
const cityList = ref([])
const feedbackForm = reactive({ provinceId: 0, cityId: 0, address: '' })

const selectedRegionForMap = computed(() => {
  const province = provinceList.value.find((p) => p.province_id === feedbackForm.provinceId)
  const city = cityList.value.find((c) => c.city_id === feedbackForm.cityId)
  return {
    province: province ? province.province_name : '',
    city: city ? city.city_name : ''
  }
})

const openMapPicker = () => { mapPickerVisible.value = true }

const handleProvinceChange = async (provinceId) => {
  feedbackForm.cityId = 0
  cityList.value = []
  // await 加载该省份城市列表...
}

const normalizeRegionName = (name) => {
  if (!name) return ''
  return String(name)
    .replace(/(省|市|自治区|自治州|地区|特别行政区|回族自治区|维吾尔自治区|壮族自治区)$/g, '')
    .trim()
}

const handleLocationSelect = async (data) => {
  if (data.address) feedbackForm.address = data.address

  const provinceName = normalizeRegionName(data.province)
  const cityName = normalizeRegionName(data.city)

  if (provinceName && provinceList.value.length) {
    const province = provinceList.value.find((p) =>
      normalizeRegionName(p.province_name).includes(provinceName) ||
      provinceName.includes(normalizeRegionName(p.province_name))
    )
    if (province) {
      feedbackForm.provinceId = province.province_id
      // 必须 await 城市列表异步加载完成，否则 nextTick 时 cityList 可能为空
      await handleProvinceChange(province.province_id)

      if (cityName && cityList.value.length) {
        const city = cityList.value.find((c) =>
          normalizeRegionName(c.city_name).includes(cityName) ||
          cityName.includes(normalizeRegionName(c.city_name))
        )
        if (city) feedbackForm.cityId = city.city_id
      }
    }
  }
}
</script>

<template>
  <el-input v-model="feedbackForm.address">
    <template #append>
      <el-button :icon="MapLocation" @click="openMapPicker">地图定位</el-button>
    </template>
  </el-input>

  <MapLocationPicker
    v-model="mapPickerVisible"
    :region="selectedRegionForMap"
    @select="handleLocationSelect"
  />
</template>
```

## 注意事项

- **调用页面的 `handleProvinceChange` 必须返回 Promise**（使用 async/await 加载城市列表），`handleLocationSelect` 也必须为 async 并 `await handleProvinceChange(...)`，否则城市列表还没加载完就开始匹配，会导致 cityId 无法回填
- **务必在调用页面导入 `nextTick`**：`import { nextTick } from 'vue'`，否则 `handleLocationSelect` 中会报 `ReferenceError`
- 高德瓦片国内速度快，但坐标系为 GCJ02；组件已内置 WGS84/GCJ02 转换
- OpenStreetMap 在国内可能加载超时，可作为备选瓦片
- 浏览器定位需要 HTTPS 或 localhost，且用户需授权位置权限；建议 `enableHighAccuracy: false` 以更快返回城市级精度
- 反地理编码已改为 **BigDataCloud 优先**，超时 4 秒；若返回地址但缺少街道，或完全失败，则再尝试 Nominatim 4 秒超时，以尽量补全街道信息
- Nominatim 在国内网络下可能返回繁体中文（如“大連市”），组件已使用 `opencc-js` 将反地理编码结果统一转为简体中文，确保后续省份/城市模糊匹配成功
- 对 `AbortError`（超时或请求取消）不做控制台警告，避免噪音
- 如需更精确的中文地址解析，建议接入高德或百度逆地理编码 API 并配置 Key
- 自定义 `divIcon` 可替代 Leaflet 默认 marker，避免生产环境默认图标 404
- 对话框使用 `width="85vw"` + `max-width: 900px` + `max-height: 90vh`，顶部 `margin-top: 5vh`。中间内容区域（地图+地址卡片）滚动，顶部工具栏、地图下方“定位到当前位置”操作栏和底部按钮始终可见，避免地图覆盖全屏无法操作
- 地图高度固定为 `280px`（最小 `200px`），不随视口百分比变化，防止小屏幕上地图过大
- 打开对话框后通过 `setTimeout(..., 260)` 调用 `mapInstance.invalidateSize()`，修正对话框动画期间 Leaflet 尺寸计算偏差
- 若用户已填写省份/城市，通过 `region` prop 传入，组件打开时会调用 Nominatim 搜索并定位到该区域
- 对话框与 Leaflet 控件统一使用中文简体字体：`"PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", sans-serif`
- 街道输入框与详细地址联动：编辑街道后自动同步到详细地址末尾；确认选点时也会把街道合并到详细地址中，防止数据丢失
- 地图容器使用 `isolation: isolate` 和相对定位，操作栏/地址卡片使用更高 `z-index`，确保不会被地图内部控件覆盖

## 资源

- `assets/MapLocationPicker.vue`：可直接复制到项目使用的组件模板
